<?php


/*
Plugin Name: Philosophy-Companion
Plugin URI:
Description: Companion plugin for the philosophy theme
Version: 1.0
Author: LWHH
Author URI:
License: GPLv2 or Later
Text Domain: philosophy_companion

*/

//echo "Hello World";

function philosophy_companion_register_my_cpts_book() {

	/**
	 * Post Type: Books.
	 */

	$labels = array(
		"name" => __( "Books", "philosophy" ),
		"singular_name" => __( "Book", "philosophy" ),
		"all_items" => __( "My Books", "philosophy" ),
		"featured_image" => __( "Book Cover", "philosophy" ),
	);

	$args = array(
		"label" => __( "Books", "philosophy" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"show_in_rest" => false,
		"rest_base" => "",
		"has_archive" => "notes",
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => array( "slug" => "note", "with_front" => false ),
		"query_var" => true,
		"menu_position" => 6,
		"menu_icon" => "dashicons-book",
		"supports" => array( "title", "editor", "thumbnail", "excerpt", "page-attributes" ),
	);

	register_post_type( "book", $args );
}

add_action( 'init', 'philosophy_companion_register_my_cpts_book' );
